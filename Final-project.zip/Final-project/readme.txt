Online Telemedicine service

1) Unzip the Final-project file

2) Upload the " Final-project " folder in VS Code IDE.

3) Install all the dependencies that are in the package.json file through the VS Code terminal. 

4) Turn on mongodb on your computer.

5) In VS Code terminal type " npm run dev " the app will run in http://localhost:3000/



C S-532-M01/C S-382-M01
Final Project


Done by
Anik Alvi 
(800773703)
&
Minhajuddin Ahmed
(800786864)

