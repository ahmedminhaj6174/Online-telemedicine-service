const express = require("express");
const path = require("path");
const dotenv = require('dotenv').config();
const mongoose = require('mongoose');

console.log("test");

const Joi = require('@hapi/joi');
const email = require('../email/sendmailtoall');

const app = express();

const ejs = require("ejs");

require("./db/conn");

const Register = require("./models/registers");

// const async = require("ejs/lib/async");

const port = process.env.PORT || 3000;

const static_path = path.join(__dirname, "../public");
const template_path = path.join(__dirname, "../templates/views");
const partial_path = path.join(__dirname, "../templates/partials");

const onSuccess = "Appointment was successfully made! you will soon recieve an email on the confirmation of your appointment timing.";
const onFailure = "Appointment Wasn't successful. Please try again later.";
const schema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    time: {
        type: String,
        required: true
    },
    appointmentTime: {
        type: String,
        required: true
    }
});

const Model = mongoose.model('appointments', schema);

function validate(appointment) {
    const schema = {
        name: Joi.string().min(3).max(100).required(),
        email: Joi.string().min(3).max(255).required().email(),
        phone: Joi.string().min(3).max(100).required(),
        time: Joi.string().min(1).max(16).required(),
    }

    return Joi.validate(appointment, schema);
    
}



app.use(express.json());
app.use(express.urlencoded({extended:false}));


app.use(express.static(static_path));

app.set("view engine", "ejs");
app.set("views", template_path);

// ejs.registerPartials(partial_path);

app.get("/",(req, res) =>{
    res.render("index")
});
app.get("/register",(req, res) =>{
    res.render("register")
});

app.get("/login",(req, res) =>{
    res.render("login")
});

// creating a new user in database
app.post("/register", async (req, res) =>{
    try {
        const password = req.body.password;
        const cpassword = req.body.confirmpassword;

        if( password === cpassword) {

            const registerUser = new Register ({

                firstname: req.body.firstname,
                lastname: req.body.lastname,
                email:req.body.email,
                inlineRadioOptions:req.body.inlineRadioOptions,
                phone:req.body.phone,
                age:req.body.age,
                password:password,
                confirmpassword:cpassword
            
            })

            const registered = await registerUser.save();
            res.status(201).render("index");

        }else{
            res.send("password not matching")
        }
    } catch (error) {
        res.status(400).send(error);
    }
});

// Login check
app.post("/login", async (req, res) =>{
    try {
        const email = req.body.email;
        const password = req.body.password;

        const useremail = await Register.findOne({email:email});
        
        if (useremail.password === password) {
            res.status(201).render("booking",{ appointment: { status: '', message: '' } });
        } else {
            res.send("invalid login details");
        }

    } catch (error) {
        res.status(400).send("invalid login details")
    }
});


app.get('/booking', async (req, res) => {
    res.render('booking', { appointment: { status: '', message: '' } });
    
});

app.post('/booking', async (req, res) => {
    // console.log("I am here!");
    const { error } = validate(req.body);
    if(error) return res.render('booking', { appointment: { status: 'notMade', message: error.details[0].message } });

    const newAppointment = new Model({
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone,
        appointmentTime: req.body.time,
        time: new Date(),
    });
    await newAppointment.save();

    email(process.env.YOUR_EMAIL, 'The appointment', 'An appointment on your clinic',
         `<b>${req.body.name}</b> has tried to take an appointment on ${req.body.time}, you can contact him via email on ${req.body.email} or call on ${req.body.phone}...`)

    email(req.body.email, 'Info on the appointment', 'Your appointment', `You have tried to take out your time and have willing to have an appointment on <b>${req.body.time}</b> and soon will get a confirmation email on the real appointment time. have a grat day.`)

    res.render('booking', { appointment: { status: 'made', message: onSuccess } });
});

app.listen(port, ()=>{
    console.log(`server is running at port no ${port}`);
})
